
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class Bid {
	private String ItemId="";
	private String Time="";
	private String Amount="";
	private User binder=new User();
	public void setItemId(String ItemId){
		this.ItemId=ItemId;
	}
	public void setTime(String Time){
		this.Time=Time;
	}
	public void setAmount(String Amount){
		this.Amount=Amount;
	}
	public void setBiderId(String BiderId){
		this.binder.setUserId(BiderId);
	}
	public void setBiderrating(String rating){
		this.binder.setRating(rating);
	}
	public void setBiderCountry(String country){
		this.binder.setCountry(country);
	}
	public void setBiderLocation(String location){
		this.binder.setLocation(location);
	}
	public void setBiderUserid(String UserId){
		this.binder.setUserId(UserId);
	}
	public User getUser(){
		return this.binder;
	}
	public String getItemId(){
		return this.ItemId;
	}
	public String getTime(){
		return this.Time;
	}
	public String getAmount(){
		return this.Amount;
	}
}
