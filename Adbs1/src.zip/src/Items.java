import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Items {
/**用于构建整个Items对象
 * 
 */
	static List itermList=new ArrayList();
	//存储itermID，判断是否存在重复的item
	static List userList=new ArrayList();
	static String split=",,";
	//存储UserID,判断是否存在重复的user
	private String itemId;
	//ItemID
	private String name;
	//Item Name
	private String Currently=null;
	private String BuyPrice = null;
	private String FirstBid=null;
	private String NumberOfBids=null;
	private String Country=null;
	private String Location=null;
	private String Latitude=null;
	private String Longitude=null;
	private String start=null;
	private String ends=null;
	private String SellerId=null;
	private Bid bid;
//	private String SellerRating;
	private String Description;
	private List catagroyList=new ArrayList();
	private List bids=new ArrayList();
	public void setItemid(String itemId){
		this.itemId=itemId;
	}
	public void setName(String Name){
		this.name=Name;
	}
	public void setCurrently(String Currently){
		this.Currently=Currently;
	}
	public void setBuyPrice(String BuyPrice){
		this.BuyPrice=BuyPrice;
	}
	public void setFirstBid(String FirstBid){
		this.FirstBid=FirstBid;
	}
	public void setNumberOfBids(String NumberOfBids){
		this.NumberOfBids=NumberOfBids;
	}
	public void setCountry(String Country){
		this.Country=Country;
	}
	public void setLocation(String Location){
		this.Location=Location;
	}
	public void setLatitude(String Latitude){
		this.Latitude=Latitude;
	}
	public void setLongitude(String Longitude){
		this.Longitude=Longitude;
	}
	public void setstart(String start){
		this.start=start;
	}
	public void setends(String ends){
		this.ends=ends;
	}
	public void setSellerId(String SellerId){
		this.SellerId=SellerId;
	}
	public void setDescription(String Description){
		this.Description=Description;
	}
	public void setcategory(String category){
		ItemCategory ic=new ItemCategory();
		ic.setCategory(category);
		ic.setItemId(this.itemId);
		catagroyList.add(ic);
	}
	public void bidstart(){
		bid=new Bid();
		bid.setItemId(this.itemId);
	}
	public void bidend(){
		bids.add(bid);
	}
	public void setbidTime(String Time){
		bid.setTime(Time);
	}
	public void setbidAmount(String Amount){
		bid.setAmount(Amount);
	}
	public void setbidCountry(String Country){
		bid.setBiderCountry(Country);
	}
	public void setbidBiderId(String BiderId){
		bid.setBiderId(BiderId);
	}
	public void setbidrating(String rating){
		bid.setBiderrating(rating);
	}
	public void setbidlocation(String location){
		bid.setBiderLocation(location);
	}
	public void setbiduserid(String UserId){
		bid.setBiderUserid(UserId);
	}
	public void writeTOcsv() throws IOException{
		//写item
		if(!itermList.contains(this.itemId)){
		System.out.println("写入item");
		//写入顺序：ItemID+++++name++++++currentyly+++++++buyprice++++FirstBid+++++NumberOfBids++++.....
		FileWriter fwitem=new FileWriter("./item.csv",true);
		fwitem.write(this.itemId+split);
		fwitem.write(this.name+split);
		fwitem.write(this.Currently+split);
		fwitem.write(this.BuyPrice+split);
		fwitem.write(this.FirstBid+split);
		fwitem.write(this.NumberOfBids+split);
		fwitem.write(this.Country+split);
		fwitem.write(this.Location+split);
		fwitem.write(this.Latitude+split);
		fwitem.write(this.Longitude+split);
		fwitem.write(this.start+split);
		fwitem.write(this.ends+split);
		fwitem.write(this.SellerId+split);
		fwitem.write(this.Description);
		fwitem.write("\r\n");
		itermList.add(this.itemId);
		
		fwitem.flush();
		fwitem.close();
		
		
		//写itemcategory
		FileWriter fwcategory=new FileWriter("./category.csv",true);
		System.out.println("写入category");
		//写入顺序：ItemID+++++Category
		for(int i=0;i<catagroyList.size();i++){
			ItemCategory ic=(ItemCategory) catagroyList.get(i);
			fwcategory.write(ic.getItemId()+split);
			fwcategory.write(ic.getCategory());
			fwcategory.write("\r\n");
		}
		fwcategory.flush();
		fwcategory.close();
		//写bid
		FileWriter fwbid=new FileWriter("./bid.csv",true);
		System.out.println("写入bid");
		//写入顺序：ItemID+++++++++++Time+++++++Amount
		for(int i=0;i<bids.size();i++){
			Bid b=(Bid) bids.get(i);
			fwbid.write(b.getItemId()+split);
			fwbid.write(b.getTime()+split);
			fwbid.write(b.getAmount());
			fwbid.write("\r\n");
		}
		fwbid.flush();
		fwbid.close();
		//写users
		FileWriter fwusers=new FileWriter("./users.csv",true);
		System.out.println("写入users");
		for(int i=0;i<bids.size();i++){
			System.out.println("写入users");
			Bid b=(Bid) bids.get(i);
			User u=b.getUser();
			if(!userList.contains(u.getUserId())){
				//写入顺序：用户ID+++++rating++++++country+++++++location
			fwusers.write(u.getUserId()+split);
			fwusers.write(u.getRating()+split);
			fwusers.write(u.getCountry()+split);
			fwusers.write(u.getLocation());
			fwusers.write("\r\n");
			userList.add(u.getUserId());
			}else
				System.out.println("User已存在");
		}
		fwusers.flush();
		fwusers.close();
		}else{
			System.out.println("ItemID已存在");
		}
	}
	
}
