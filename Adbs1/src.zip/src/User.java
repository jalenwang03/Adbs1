

import java.io.FileWriter;
import java.io.IOException;

public class User {
	private String UserId="";
	private String Location="";
	private String rating="";
	private String Country="";
	public void setUserId(String UserId){
		this.UserId=UserId;
	}
	public void setLocation(String Location){
		this.Location=Location;
	}
	public void setCountry(String Country){
		this.Country=Country;
	}
	public void setRating(String rating){
		this.rating=rating;
	}
	public String getUserId(){
		return this.UserId;
	}
	public String getLocation(){
		return this.Location;
	}
	public String getCountry(){
		return this.Country;
	}
	public String getRating(){
		return this.rating;
	}
}
