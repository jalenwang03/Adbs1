

/* Parser skeleton for processing item-???.xml files. Must be compiled in
 * JDK 1.5 or above.
 *
 * Instructions:
 *
 * This program processes all files passed on the command line (to parse
 * an entire diectory, type "java MyParser myFiles/*.xml" at the shell).
 *
 */

import java.io.FileReader;
import java.io.IOException;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.Locale;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;


public class MySAX extends DefaultHandler
{
	Bid bid;
	Items items;
	private String tag = null;
	//标识当前tag
	private String currentNode=null;
	//标识当前属于哪个Node
	
	private Attributes myatts;

    public static void main (String args[])
	throws Exception
    {
	XMLReader xr = XMLReaderFactory.createXMLReader();
	MySAX handler = new MySAX();
	xr.setContentHandler(handler);
	xr.setErrorHandler(handler);

				// Parse each file provided on the
				// command line.
	for (int i = 0; i < args.length; i++) {
	    FileReader r = new FileReader(args[i]);
	    xr.parse(new InputSource(r));
	}
    }


    public MySAX ()
    {
    	super();
    }

    /* Returns the amount (in XXXXX.xx format) denoted by a money-string
     * like $3,453.23. Returns the input if the input is an empty string.
     */
    static String strip(String money) {
        if (money.equals(""))
            return money;
        else {
            double am = 0.0;
            NumberFormat nf = NumberFormat.getCurrencyInstance(Locale.US);
            try { am = nf.parse(money).doubleValue(); }
            catch (ParseException e) {
                System.out.println("This method should work for all " +
                                   "money values you find in our data.");
                System.exit(20);
            }
            nf.setGroupingUsed(false);
            return nf.format(am).substring(1);
        }
    }

    ////////////////////////////////////////////////////////////////////
    // Event handlers.
    ////////////////////////////////////////////////////////////////////


    public void startDocument ()
    {
//    	System.out.println("Start document");
    }


    public void endDocument ()
    {
//    	System.out.println("End document");
    }


    public void startElement (String uri, String name,
			      String qName, Attributes atts)
    {
    		myatts=atts;
    		//将attribute值传入message
    		tag = qName;
    		if("Bids".equals(name)||"Bids".equals(qName)){
    			items.bidstart();
    		}
//    		System.out.println(tag);
    		if("Item".equals(qName)||"Item".equals(name)){
    			items=new Items();
    		}
//    		System.out.println(atts.getLength());
    		if("Item".equals(qName)||"Item".equals(name)){
    			//如果当前读取的是item字段，则后续内容作用于item
    			currentNode="Item";
    		}
    		if("Bids".equals(qName)||"Bids".equals(qName)){
    			//如果当前读取的是Bids字段，则后续内容作用于bids
    			currentNode="Bids";
    		}
    }
    	


    public void endElement (String uri, String name, String qName)
    {
    	if("Bids".equals(name)||"Bids".equals(qName)){
			items.bidend();
		}
    	if("Item".equals(qName)||"Item".equals(name)){
			//Item结束，表明一条记录结束，触发write方法
    		try {
				items.writeTOcsv();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if("Bids".equals(qName)||"Bids".equals(qName)){
			//如果当前读取的是Bids字段，则后续内容作用于bids
			currentNode="Item";
		}
    }


    public void characters (char ch[], int start, int length)
    {
    	
    	String content = new String(ch,start,length);
    	if(tag!=null){
	    switch (tag) {
	    case "Item":
	    	//如果标签为item，写入itemid
	    	items.setItemid(myatts.getValue("ItemID"));
	    	tag = null;
	    	break;
	    case "Name":
	    	items.setName(content);
	    	//如果标签是name，直接写入content
	    	tag = null;
	    	break;
	    case "Category":
	    	//如果标签是Category，直接写入content
	    	items.setcategory(content);
	    	tag = null;
	    	break;
	    case "Currently":
	    	items.setCurrently(content);
	    	tag = null;	
	    	break;
	    case "First_Bid":
	    	items.setFirstBid(content);
	    	tag = null;
	    	break;
	    case "Number_of_Bids":
	    	items.setNumberOfBids(content);
	    	tag = null;
	    	break;
	    //	=======
//	    case "Bids":
//	    	items.bidstart();
//	    	tag=null;
//	    	break;
	    	
	    //  ======
	    case "Bidder":
	    	items.setbidrating(myatts.getValue("Rating"));
	    	items.setbiduserid(myatts.getValue("UserID"));
	    	tag=null;
	    	break;
	    case "Location":
	    	if("Item".equals(currentNode)){
	    		//如果是Item的location，则写入item
	    		items.setLocation(content);
	    		items.setLatitude(myatts.getValue("Latitude"));
	    		items.setLongitude(myatts.getValue("Longitude"));
	    	}else if("Bids".equals(currentNode)){
	    		//如果是bids的localtion，则写入bids
	    		items.setbidlocation(content);
	    	}
	    	tag=null;
	    	break;
	    case "Country":
	    	if("Item".equals(currentNode)){
	    		//如果是Item的country，则写入item
	    		items.setCountry(content);
	    	}else if("Bids".equals(currentNode)){
	    		//如果是bids的country，则写入bids
	    		items.setbidCountry(content);
	    	}
	    	tag=null;
	    	break;
	    case "Time":
	    	items.setbidTime(content);
	    	tag=null;
	    	break;
	    case "Amount":
	    	items.setbidAmount(content);
	    	tag=null;
	    	break;
	    case "Started":
	    	items.setstart(content);
	    	tag=null;
	    	break;
	    case "Ends":
	    	items.setends(content);
	    	tag=null;
	    	break;
	    case "Seller":
	    	items.setSellerId(myatts.getValue("UserID"));
	    	tag=null;
	    	break;
	    case "Description":
	    	items.setDescription(content);
	    	tag = null;
	    	break;   	
	    }
    	}
    }
}
	    	
    	
	    	
	    	
	
